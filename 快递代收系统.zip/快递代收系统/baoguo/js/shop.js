//修改包裹信息

$('.getEdit').click(function(){
	var idstr = $(this).data('edit');
	var es = $(this).data('es');
	
	console.log(idstr);
	
	if(es == '0'){
		$(this).html('取消修改');
		$(this).data('es','1');
		$('#'+idstr+'get').css('display','block');
		$('#'+idstr+'c').css('display','none');
	}else{
		$(this).html('修改');
		$(this).data('es','0');
		$('#'+idstr+'get').css('display','none');
		$('#'+idstr+'c').css('display','block');
	}
	
	
	
});

//批量取货quhuoAll

$('#quhuoAll').click(function(){
	
	var ids = '';
	
	var bids = '';
	
	$('.data-ids').each(function(){
		
		ids += $(this).data('ids')+',';
		
		bids += $(this).data('bids')+',';
		
	});
	
	ids=ids.substring(0,ids.length-1);
	bids=bids.substring(0,bids.length-1);
	
	$('#b_bid_all').html(bids);
	
	$('#ckquhuoAll').data('sid',ids);
	
	$('#getBgAllMod').modal('show');
});

//批量取货--2

$('#ckquhuoAll').click(function(){
	
	var mycode = $(this).data('mycode');
	var sid = $(this).data('sid');
	
	var inputcode = $('#inputcodeAll').val();
	
	if(inputcode != '123456'){
	//if(inputcode != mycode){
		
		$('#quhuoinfo').html('取货码错误！');
		$('#quhuoinfo').css('color',"red");
		
		$('#quhuoMod').modal('show');
		return;		
	}
	
	window.location.href="../baoguo/quhuo.php?sid="+sid+"&methodS=quhuoAll";
		
});

//取货--1

$('.getBg').click(function(){
	
	var id = $(this).data('id');
	var name = $(this).data('name');
	var tel = $(this).data('tel');
	var bid = $(this).data('bid');
	var code = $(this).data('code');
	
	$('#b_bid').html(bid);
	$('#b_name').html(name);
	$('#b_tel').html(tel);
	$('#quhuo').data('mycode',code);
	$('#quhuo').data('sid',id);
	
	$('#getBgMod').modal('show');
});

//取货--2

$('#quhuo').click(function(){
	
	var mycode = $(this).data('mycode');
	var sid = $(this).data('sid');
	
	var inputcode = $('#inputcode').val();
	
	if(inputcode != '123456'){
	//if(inputcode != mycode){
		
		$('#quhuoinfo').html('取货码错误！');
		$('#quhuoinfo').css('color',"red");
		
		$('#quhuoMod').modal('show');
		return;		
	}
	
	window.location.href="../baoguo/quhuo.php?sid="+sid+"&methodS=quhuo";
		
});

//首页单取货--1
$('.getBg1').click(function(){
	
	var id = $(this).data('id');
	var name = $(this).data('name');
	var tel = $(this).data('tel');
	var bid = $(this).data('bid');
	var code = $(this).data('code');
	
	$('#b_bid').html(bid);
	$('#b_name').html(name);
	$('#b_tel').html(tel);
	$('#quhuo1').data('mycode',code);
	$('#quhuo1').data('sid',id);
	
	$('#getBgMod').modal('show');
});
//首页单取货--2
$('#quhuo1').click(function(){
	
	var mycode = $(this).data('mycode');
	var sid = $(this).data('sid');
	
	var inputcode = $('#inputcode').val();
	
	if(inputcode != '123456'){
	//if(inputcode != mycode){
		
		$('#quhuoinfo').html('取货码错误！');
		$('#quhuoinfo').css('color',"red");
		
		$('#quhuoMod').modal('show');
		return;		
	}
	
	window.location.href="../baoguo/index.php?sid="+sid+"&methodS=quhuo";
		
});

//取货返回
if($('#quhuoReturn').val() == 1){
	$('#quhuoinfo').html('取货成功！');
	$('#quhuoinfo').css('color',"#00ad19");
	$('#quhuoMod').modal('show');
}

//取货返回
if($('#editReturn').val() == 1){
	$('#quhuoinfo').html('修改成功！');
	$('#quhuoinfo').css('color',"#337ab7");
	$('#quhuoMod').modal('show');
}



//回滚 -- 1
$('.hgBg').click(function(){
	
	var id = $(this).data('id');
	var name = $(this).data('name');
	var tel = $(this).data('tel');
	var bid = $(this).data('bid');
	var code = $(this).data('code');
	
	$('#b_bid').html(bid);
	$('#b_name').html(name);
	$('#b_tel').html(tel);
	$('#huigun').data('mycode',code);
	$('#huigun').data('sid',id);
	
	$('#getBgMod').modal('show');
});

//签收回滚 -- 2

$('#huigun').click(function(){
	
	var mycode = $(this).data('mycode');
	var sid = $(this).data('sid');
	
	var inputcode = $('#inputcode').val();
	
	if(inputcode != '123456'){
	//if(inputcode != mycode){
		
		$('#quhuoinfo').html('管理员密码错误！');
		$('#quhuoinfo').css('color',"red");
		
		$('#quhuoMod').modal('show');
		return;		
	}
	window.location.href="../baoguo/log.php?sid="+sid+"&methodS=huigun";
		
});

//回滚返回
if($('#huigunReturn').val() == 1){
	$('#quhuoinfo').html('重新签收成功！');
	$('#quhuoinfo').css('color',"#00ad19");
	$('#quhuoMod').modal('show');
	
}


//F5
$('.wrload').click(function(){
	
	var href = window.location.href;
	
	if(href.indexOf('quhuo.php')>0){
		window.location.href = '../baoguo/quhuo.php';
	}else if(href.indexOf('log.php')>0){
		window.location.href = '../baoguo/log.php';
	}else{
		window.location.href = '../baoguo/';
	}
	
	
});

$('#quhuoMod').on('hidden.bs.modal', function (e) {
	var href = window.location.href;
	
	if(href.indexOf('quhuo.php')>0){
		window.location.href = '../baoguo/quhuo.php';
	}else if(href.indexOf('log.php')>0){
		window.location.href = '../baoguo/log.php';
	}else{
		window.location.href = '../baoguo/';
	}
})


//入库
$('#sIn').click(function () {
	console.log('222');
    var name = $('#name').val();
    var tel = $('#tel').val();

    if(!checkTel(tel)){
        return;
    };

    var dateForm = getDateForBG();
    var code = createCode(6);

    //AJAX
    var dataString = 'name=' + name + '&tel=' + tel + '&type=-&code=' + code + '&date='+ dateForm + '&bid=&status=1&outdate=0&action=post'+ '&diyid=1&do=2&dede_fields=name,text;type,text;code,text;tel,text;date,text;status,text;bid,text;outdate,text';

    $.ajax({
        type: "POST",
        url: "../../plus/diy203.php",
        data: dataString, //传值
        success: function(data) {
            if(data.indexOf('-') != -1){
                succssMod(name,tel,data);
            }else{
                errorMod();
            }
        }
    });
	
	//window.location.reload() ;
});


function createCode(num){

    var code = '';
    for(var i=0;i<num;i++){
        code+=Math.floor(Math.random()*10);
    }
    return code;
}

function getDateForBG() {

    var mydate = new Date();
    var myday;


    var myhours = mydate.getHours();
    var mymin = mydate.getMinutes();

    var mydatestr = mydate.toLocaleDateString();

    var datearr = mydatestr.split('/');

    var newdataarr=datearr[0];

    if(datearr[1]<10){
        newdataarr = newdataarr + '/0' + datearr[1]
    }else{
        newdataarr = newdataarr + '/' + datearr[1]
    }

    if(datearr[2]<10){
        newdataarr = newdataarr + '/0' + datearr[2]
    }else{
        newdataarr = newdataarr + '/' + datearr[2]
    }

    var dateForm = newdataarr + " " + myhours + ":" + mymin;

    return dateForm;
}

function succssMod(name,tel,bid){
    $("#name").val('');
    $("#tel").val('');

    clearMod();
	
    $('#bidBG').html('编号：' + bid);
    $('#nameBG').html('姓名：' + name);
    $('#telBG').html('手机：' + tel);

    $('#bidBG').css('color',"#00ad19");
    $('#nameBG,#telBG').css('color',"#2ca6fa");

    $('#myModal').modal('show');
}

function errorMod(){
    $("#name").val('');
    $('#tel').val('');

    clearMod();
	
    $('#formText').html('签收失败！');
    $('#formText').css('font-size','24px');
    $('#formText').css('color',"red");
    $('#myModal').modal('show');
}

function clearMod(){
    $('#formText').html('');
    $('#bidBG').html('');
    $('#nameBG').html('');
    $('#telBG').html('');
}

function checkTel(tel) {

    var tel_str = /^1([38]\d|4[57]|5[0-35-9]|7[0-9]|8[89])\d{8}$/;

    if(!tel_str.test(tel)){
        $("#tel").focus();
        $('#tel').val('');
        clearMod();
        $('#formText').html('手机号输入错误，请重新输入!');
        $('#formText').css('font-size','18px');
        $('#formText').css('color','red');
        $('#myModal').modal('show');
        return false;
    }

    return true;
}

$("#checkall").click( 
	function(){ 
		if(this.checked){ 
			$("input[name='checkname']").each(function(){this.checked=true;}); 
			}else{ 
			$("input[name='checkname']").each(function(){this.checked=false;}); 
		} 
	} 
);

//enter key
$(document).keydown(function(event){ 
	
	if(event.keyCode==13){ 
		
	} 
});

var oldbgc;

$('.hovertr').hover(function(){
	oldbgc = $(this).css('background');
	$(this).css('background','#5bc0de');
},function(){
	$(this).css('background',oldbgc);
});