<?php
error_reporting(0);//(E_ALL);
//header( " Pragma: no-cache " );		// 告诉客户端浏览器不使用缓存，兼容HTTP 1.0 协议

require_once(dirname(__FILE__) . "/../include/pdo.class.php");
require_once(dirname(__FILE__) . "/../include/page.class1.php");

date_default_timezone_set ("PRC");

$pagesize = 20;//每页显示条目数
$page = isset($_GET['page']) ? is_numeric($_GET['page']) ? htmlentities($_GET['page']) : 1 : 1; //当前页
$index = ($page - 1)*($pagesize); //索引号
$mydate = date("Y/m/d");
$mydate2 = date("Y年m月d日");
$mydateym = date("Y/m");
$outdate = date("Y/m/d H:i:s",time());

$sid = isset($_GET['sid']) ? htmlentities($_GET['sid']) : '';  //sid

$methodS = isset($_GET['methodS']) ? htmlentities($_GET['methodS']) : '';  //status0

/*-------------------------------------------------筛选表参数-------------------------------------------------*/
 
/*-------------------------------------------------拼接查询条件-------------------------------------------------*/
$where = " status = 1 AND date like '%".$mydate."%'";

$where .= " ";


if ($order == 'id') $where .=" ORDER BY id DESC";
else $where .="  ORDER BY id DESC";

/*-------------------------------------------------如果需要关键词添加，查看本目录下源文件有实例代码   -------------------------------------------------*/

//@wyy
if($methodS == 'quhuo'){
	$qh_data = $db->execute("update baoguo set status=0,outdate='".$outdate."' WHERE id=".$sid);
}

$mlist = $db->getMore("SELECT * FROM baoguo WHERE ".$where." LIMIT ".$index.",".$pagesize);

//获取个数
$bg_sum = $db->getOne("SELECT COUNT(*) AS num FROM baoguo where status = 1");//获全部取未取包裹总数
$bg_nums = intval($bg_sum['num']);//所有记录数

$bgno_sum = $db->getOne("SELECT COUNT(*) AS num FROM baoguo where status = 1 AND date like '%".$mydate."%'");//获当天取未取包裹总数
$bgno_nums = intval($bgno_sum['num']);

$bgday_sum = $db->getOne("SELECT COUNT(*) AS num FROM baoguo where date like '%".$mydate."%'");//获取当天包裹总数
$bgday_sums = intval($bgday_sum['num']);

$bgs_sum = $db->getOne("SELECT COUNT(*) AS num FROM baoguo where date like '%".$mydateym."%'");//当月总快递数量
$bgs_nums = intval($bgs_sum['num']);//当月总快递数量



$allpages = ceil($bg_nums/$pagesize); //共有多少页

?>

<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<meta content="yes" name="apple-mobile-web-app-capable">
	<meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
    <!--link rel="icon" href="/favicon.ico"-->

    <title>快递代收服务系统</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">


    <!-- Custom styles for this template -->
    <link href="css/shop.css" rel="stylesheet">

    <style>
      body {
        padding-top: 30px;
        padding-bottom: 20px;
      }
    </style>

    <!--[if lt IE 9]>
      <script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>
	<input type='hidden' id='quhuoReturn' value='<?php echo $qh_data;?>'>
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">快递代收服务系统</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="/baoguo">签收</a></li>
            <li><a href="/baoguo/quhuo.php">取件</a></li>
            <li><a href="/baoguo/log.php">历史包裹</a></li>
            
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li>
				<button type="button" class="btn btn-sm btn-warning" style='margin-top: 0.8em; margin-left:1.2em'>今日包裹：<span class="badge badge-light"><?php echo $bgno_nums;?> / <span id='bidIn'><?php echo $bgday_sums;?></span></span></button>
			</li>
			<li>
				<button type="button" class="btn btn-sm  btn-info" style='margin-top: 0.8em; margin-left:1.2em'>全部未取：<span class="badge badge-light"><?php echo $bg_nums  ; ?></span></button>
			</li>
			<li>
				<button type="button" class="btn btn-sm  btn-danger" style='margin-top: 0.8em; margin-left:1.2em'>本月签收：<span class="badge badge-light"><?php echo $bgs_nums  ; ?></span></button>
			</li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container" style=' position: relative; z-index: 2;'>
        <h2 style='color:#fff;'>签收快递</h2>
        <div class="form-horizontal s-form" style='z-index:99;'>
          <div class="form-group">
            <label for="name" class="col-sm-2 control-label">姓名</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="name" placeholder="请输入姓名">
            </div>
          </div>
          <div class="form-group">
            <label for="tel" class="col-sm-2 control-label">手机号码</label>
            <div class="col-sm-10">
              <input type="tel" class="form-control" id="tel" placeholder="请输入手机号码">
            </div>
          </div>

          <div class="form-group" style="margin-top: 30px;">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="button" class="btn btn-primary col-sm-4 col-xs-12" id="sIn">点击入库</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container" style=' position: relative; z-index: 2;'>
	  
      <!-- Example row of columns -->
      <div class="row">
        <table class="table table-striped table-bordered">
          <thead>
          <tr>
            <th>#</th>
            <th  class='hidden-xs'>姓名</th>
            <th>手机</th>
            <th>编号</th>
			<th class='hidden-xs'>签收时间</th>
            <th>操作</th>
          </tr>
          </thead>
          <tbody>
           <?php
            $bg_num = count($mlist);
            require_once("../dede/config_h.php");
            require_once("../include/common.inc.php");
            require_once("../include/helpers/archive.helper.php");
            //echo $bg_num;
            ?>

            <?php for ($i = 0;$i < $bg_num;$i++){?>
			<tr class='hovertr'>
				<th scope="row"><?php echo $i+1;?></th>
				<td class='hidden-xs'><?php echo $mlist[$i]['name'];?></td>
				<td><?php echo $mlist[$i]['tel'];?></td>
				<td>
					<code style='font-size:16px;'><?php echo $mlist[$i]['bid'];?></code>
				</td>
				<td class='hidden-xs'><?php echo $mlist[$i]['date'];?></td>
				<td>
					<button type="button" class="btn btn-sm btn-success getBg1 col-xs-12" data-id='<?php echo $mlist[$i]['id'];?>' data-name='<?php echo $mlist[$i]['name'];?>'  data-tel='<?php echo $mlist[$i]['tel'];?>'  data-code='<?php echo $mlist[$i]['code'];?>' data-bid='<?php echo $mlist[$i]['bid'];?>'>取货</button>
				</td>
			</tr>	
            <?php }?>
          </tbody>
        </table>
      </div>
	  <?php if ($bg_num == 0 ) echo '<p ><b>今日没有包裹信息</b></p>';?>
		<?php if ($bgno_nums > 15){?>
			<nav aria-label="Page navigation example">
				<?php if ($bgno_nums > 5){?>

				<ul class="pagination justify-content-end">

					<?php
							$makepage = new SubPages($pagesize,$bgno_nums,$page,5,"/baoguo/index.php?page=",2); //echo $makepage->subPageCss2();
					?>

				</ul>

				<?php }?>
			</nav>
		<?php }?>
      <hr>

      <footer>
        <p>&copy; 2017 Company, Inc. </p>
      </footer>
    </div> <!-- /container -->


    <!-- Button trigger modal -->

    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1">
      <div class="modal-dialog modal-dialog modal-sm" role="document">
        <div class="modal-content">
          <div class="modal-header">
            
            <h4 class="modal-title" id="myModalLabel1">包裹入库信息</h4>
          </div>
          <div class="modal-body">
              <h2 id="formText"></h2>
              <h3 id="bidBG"></h3>
              <h3 id="nameBG"></h3>
              <h3 id="telBG"></h3>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary wrload"  data-dismiss="modal">知道了</button>
          </div>
        </div>
      </div>
    </div>
	
	<!-- Modal -->
    <div class="modal fade" id="getBgMod" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
      <div class="modal-dialog modal-dialog modal-sm" role="document">
        <div class="modal-content">
          <div class="modal-header">
           
            <h4 class="modal-title" id="myModalLabel2">取货信息</h4>
          </div>
		 
          <div class="modal-body">
              
              
              
			  <form>
			  <div class="form-group">
				<label for="code" class="control-label">包裹编号:</label>
				<code id="b_bid" style='font-size:16px;'></code>
			  </div>
				<div class="form-group">
				<label for="code" class="control-label">姓名:</label>
				<label id="b_name" style='color:#393747;'></label>
			  </div>
				<div class="form-group">
				<label for="code" class="control-label">电话:</label>
				<label id="b_tel" style='color:#393747;'></label>
			  </div>			  
			  <div class="form-group">
				<label for="code" class="control-label">取货码:</label>
				<input type='tel' class="form-control" id="inputcode"></input>
			  </div>
			
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary"  data-dismiss="modal" id='quhuo1' data-mycode='' data-sid=''>点击取货</button>
          </div>
		  </form>
        </div>
      </div>
    </div>
	
	<!-- Modal -->
    <div class="modal fade" id="quhuoMod" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3">
      <div class="modal-dialog modal-dialog modal-sm" role="document">
        <div class="modal-content">
          <div class="modal-header">
           
            <h4 class="modal-title" id="myModalLabel3">温馨提醒</h4>
          </div>
          <div class="modal-body">
              <h3 id='quhuoinfo'></h3>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary wrload"  data-dismiss="modal">知道了</button>
          </div>
        </div>
      </div>
    </div>
	
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/shop.js"></script>
  </body>
</html>
